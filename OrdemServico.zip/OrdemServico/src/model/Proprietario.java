/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

/**
 *
 * @author suahi
 */
public class Proprietario {
    private Integer CPF;
    private String Nome;

    public Proprietario() {
    }

    public Proprietario(Integer CPF, String Nome) {
        this.CPF = CPF;
        this.Nome = Nome;
    }

    public Integer getCPF() {
        return CPF;
    }

    public void setCPF(Integer CPF) {
        this.CPF = CPF;
    }

    public String getNome() {
        return Nome;
    }

    public void setNome(String Nome) {
        this.Nome = Nome;
    }
    
}
