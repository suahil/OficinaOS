/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

/**
 *
 * @author suahi
 */
public class Peca {
    private Integer Codigo;
    private String Modelo;
    private String Nome;

    public Peca() {
    }

    public Peca(Integer Codigo, String Modelo, String Nome) {
        this.Codigo = Codigo;
        this.Modelo = Modelo;
        this.Nome = Nome;
    }

    public Integer getCodigo() {
        return Codigo;
    }

    public void setCodigo(Integer Codigo) {
        this.Codigo = Codigo;
    }

    public String getModelo() {
        return Modelo;
    }

    public void setModelo(String Modelo) {
        this.Modelo = Modelo;
    }

    public String getNome() {
        return Nome;
    }

    public void setNome(String Nome) {
        this.Nome = Nome;
    }
    
    
}
