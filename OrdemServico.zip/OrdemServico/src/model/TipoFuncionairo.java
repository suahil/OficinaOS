package model;

public enum TipoFuncionairo {
    Gerente,
    Recepcionista,
    Mecanico;
    
}