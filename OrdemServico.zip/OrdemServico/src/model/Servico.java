/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import java.util.List;

/**
 *
 * @author suahi
 */
public class Servico {
    private Integer ID;
    private String TipoS;
    private Double Valor;
    
    private List<TipoServico> tipoServico;

    public Servico() {
    }

    public Servico(Integer ID, String TipoS, Double Valor, List<TipoServico> tipoServico) {
        this.ID = ID;
        this.TipoS = TipoS;
        this.Valor = Valor;
        this.tipoServico = tipoServico;
    }

    public Integer getID() {
        return ID;
    }

    public void setID(Integer ID) {
        this.ID = ID;
    }

    public String getTipoS() {
        return TipoS;
    }

    public void setTipoS(String TipoS) {
        this.TipoS = TipoS;
    }

    public Double getValor() {
        return Valor;
    }

    public void setValor(Double Valor) {
        this.Valor = Valor;
    }

    public List<TipoServico> getTipoServico() {
        return tipoServico;
    }

    public void setTipoServico(List<TipoServico> tipoServico) {
        this.tipoServico = tipoServico;
    }
    
    
}
