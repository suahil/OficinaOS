/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import java.sql.Date;
import java.time.LocalDate;
import java.util.List;

/**
 *
 * @author suahi
 */
public class OrdemServico {
    public Integer ID;
    public LocalDate DataEnt;
    public LocalDate DataEmi;
    private String MecanicoR;
    
    private List<Servico> servico;
    private List<Cliente> cliente;
    private List<Funcionario> funcionario;
    private List<Veiculo> veiculo;
    private List<Peca> peca;

    public OrdemServico() {
    }

    public OrdemServico(Integer ID, LocalDate DataEnt, LocalDate DataEmi, String MecanicoR, List<Servico> servico, List<Cliente> cliente, List<Funcionario> funcionario, List<Veiculo> veiculo, List<Peca> peca) {
        this.ID = ID;
        this.DataEnt = DataEnt;
        this.DataEmi = DataEmi;
        this.MecanicoR = MecanicoR;
        this.servico = servico;
        this.cliente = cliente;
        this.funcionario = funcionario;
        this.veiculo = veiculo;
        this.peca = peca;
    }

    public Integer getID() {
        return ID;
    }

    public void setID(Integer ID) {
        this.ID = ID;
    }

    public LocalDate getDataEnt() {
        return DataEnt;
    }

    public void setDataEnt(LocalDate DataEnt) {
        this.DataEnt = DataEnt;
    }

    public LocalDate getDataEmi() {
        return DataEmi;
    }

    public void setDataEmi(LocalDate DataEmi) {
        this.DataEmi = DataEmi;
    }

    public String getMecanicoR() {
        return MecanicoR;
    }

    public void setMecanicoR(String MecanicoR) {
        this.MecanicoR = MecanicoR;
    }

    public List<Servico> getServico() {
        return servico;
    }

    public void setServico(List<Servico> servico) {
        this.servico = servico;
    }

    public List<Cliente> getCliente() {
        return cliente;
    }

    public void setCliente(List<Cliente> cliente) {
        this.cliente = cliente;
    }

    public List<Funcionario> getFuncionario() {
        return funcionario;
    }

    public void setFuncionario(List<Funcionario> funcionario) {
        this.funcionario = funcionario;
    }

    public List<Veiculo> getVeiculo() {
        return veiculo;
    }

    public void setVeiculo(List<Veiculo> veiculo) {
        this.veiculo = veiculo;
    }

    public List<Peca> getPeca() {
        return peca;
    }

    public void setPeca(List<Peca> peca) {
        this.peca = peca;
    }
    
    
}
