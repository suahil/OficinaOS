/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

/**
 *
 * @author suahi
 */
public class TipoServico {
    private Integer ID;
    private String Nome;
    

    public TipoServico() {
    }

    public TipoServico(Integer ID, String Nome) {
        this.ID = ID;
        this.Nome = Nome;
    }

    public Integer getID() {
        return ID;
    }

    public void setID(Integer ID) {
        this.ID = ID;
    }

    public String getNome() {
        return Nome;
    }

    public void setNome(String Nome) {
        this.Nome = Nome;
    }
    
    
}
