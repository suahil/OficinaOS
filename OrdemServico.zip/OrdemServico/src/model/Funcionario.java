/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

/**
 *
 * @author suahi
 */
public class Funcionario {
    private Integer Matricula;
    private String Nome;
    private String Funcao;

    public Funcionario() {
    }

    public Funcionario(Integer Matricula, String Nome, String Funcao) {
        this.Matricula = Matricula;
        this.Nome = Nome;
        this.Funcao = Funcao;
    }

    public Integer getMatricula() {
        return Matricula;
    }

    public void setMatricula(Integer Matricula) {
        this.Matricula = Matricula;
    }

    public String getNome() {
        return Nome;
    }

    public void setNome(String Nome) {
        this.Nome = Nome;
    }

    public String getFuncao() {
        return Funcao;
    }

    public void setFuncao(String Funcao) {
        this.Funcao = Funcao;
    }
    
    
}
