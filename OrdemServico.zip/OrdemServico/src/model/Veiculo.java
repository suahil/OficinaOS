/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import java.util.List;

/**
 *
 * @author suahi
 */
public class Veiculo {
    private Integer Renavan;
    private String Montadora;
    private String Placa;
    private String Modelo;
    private Integer Ano;
    private Integer CpfProprietario;

    public Veiculo() {
    }

    public Veiculo(Integer Renavan, String Montadora, String Placa, String Modelo, Integer Ano, Integer CpfProprietario) {
        this.Renavan = Renavan;
        this.Montadora = Montadora;
        this.Placa = Placa;
        this.Modelo = Modelo;
        this.Ano = Ano;
        this.CpfProprietario = CpfProprietario;
    }

    public Integer getRenavan() {
        return Renavan;
    }

    public void setRenavan(Integer Renavan) {
        this.Renavan = Renavan;
    }

    public String getMontadora() {
        return Montadora;
    }

    public void setMontadora(String Montadora) {
        this.Montadora = Montadora;
    }

    public String getPlaca() {
        return Placa;
    }

    public void setPlaca(String Placa) {
        this.Placa = Placa;
    }

    public String getModelo() {
        return Modelo;
    }

    public void setModelo(String Modelo) {
        this.Modelo = Modelo;
    }

    public Integer getAno() {
        return Ano;
    }

    public void setAno(Integer Ano) {
        this.Ano = Ano;
    }

    public Integer getCpfProprietario() {
        return CpfProprietario;
    }

    public void setCpfProprietario(Integer CpfProprietario) {
        this.CpfProprietario = CpfProprietario;
    }
    
    
}
