/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

/**
 *
 * @author suahi
 */
public class Cliente {
    private Integer ID;
    private String Nome;
    private Integer CPF;
    private Integer CNPJ;
    private Integer Telefone;
    private Integer Residencial;
    private String Rua;
    private Integer Numero;
    private String Bairro;
    private String Cidade;

    public Cliente() {
    }

    public Cliente(Integer ID, String Nome, Integer CPF, Integer CNPJ, Integer Telefone, Integer Residencial, String Rua, Integer Numero, String Bairro, String Cidade) {
        this.ID = ID;
        this.Nome = Nome;
        this.CPF = CPF;
        this.CNPJ = CNPJ;
        this.Telefone = Telefone;
        this.Residencial = Residencial;
        this.Rua = Rua;
        this.Numero = Numero;
        this.Bairro = Bairro;
        this.Cidade = Cidade;
    }

    public Integer getID() {
        return ID;
    }

    public void setID(Integer ID) {
        this.ID = ID;
    }

    public String getNome() {
        return Nome;
    }

    public void setNome(String Nome) {
        this.Nome = Nome;
    }

    public Integer getCPF() {
        return CPF;
    }

    public void setCPF(Integer CPF) {
        this.CPF = CPF;
    }

    public Integer getCNPJ() {
        return CNPJ;
    }

    public void setCNPJ(Integer CNPJ) {
        this.CNPJ = CNPJ;
    }

    public Integer getTelefone() {
        return Telefone;
    }

    public void setTelefone(Integer Telefone) {
        this.Telefone = Telefone;
    }

    public Integer getResidencial() {
        return Residencial;
    }

    public void setResidencial(Integer Residencial) {
        this.Residencial = Residencial;
    }

    public String getRua() {
        return Rua;
    }

    public void setRua(String Rua) {
        this.Rua = Rua;
    }

    public Integer getNumero() {
        return Numero;
    }

    public void setNumero(Integer Numero) {
        this.Numero = Numero;
    }

    public String getBairro() {
        return Bairro;
    }

    public void setBairro(String Bairro) {
        this.Bairro = Bairro;
    }

    public String getCidade() {
        return Cidade;
    }

    public void setCidade(String Cidade) {
        this.Cidade = Cidade;
    }
    
    
    
    
}
