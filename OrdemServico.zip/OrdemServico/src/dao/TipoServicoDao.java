/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import model.TipoServico;
/**
 *
 * @author suahi
 */
public class TipoServicoDao extends Persistencia implements Dao {

    @Override
    public void gravar(Object objeto) throws Exception {
        TipoServico tipo = (TipoServico) objeto;
        PreparedStatement ps = getConexao().prepareStatement("insert into categoria (nome) values (?)");
        ps.setInt(1, tipo.getID());
        ps.setString(2, tipo.getNome());

        ps.executeUpdate();
    }

    @Override
    public void excluir(Object objeto) throws Exception {
        TipoServico tipo = (TipoServico) objeto;
        PreparedStatement ps = getConexao().prepareStatement("delete from categoria where id = ?");
        ps.setInt(1, tipo.getID());
        ps.setString(2, tipo.getNome());
        //verificar se esta certo, caso estiver modificar nos outros
        ps.executeUpdate();
    }

    @Override
    public List listar() throws Exception {
        PreparedStatement ps = getConexao().prepareStatement("select * from tipo order by nome");//mudar isso
        ResultSet rs = ps.executeQuery();
        List<TipoServico> tipos = new ArrayList();
        while (rs.next()) {
            TipoServico t = new TipoServico(rs.getInt("ID"), rs.getString("Nome"));
            tipos.add(t);
        }
        return tipos;

    }

    @Override
    public void alterar(Object objeto) throws Exception {
        TipoServico tipo = (TipoServico) objeto;
        PreparedStatement ps = getConexao().prepareStatement("update categoria set nome = ? where id = ?");
        ps.setInt(1, tipo.getID());
        ps.setString(2, tipo.getNome());

        ps.executeUpdate();
    }

}
