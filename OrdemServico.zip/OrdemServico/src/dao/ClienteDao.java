/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import java.util.List;
import model.Cliente;
import java.sql.*;
import java.util.ArrayList;

/**
 *
 * @author suahi
 */
public class ClienteDao extends Persistencia implements Dao {

    @Override
    public void gravar(Object objeto) throws Exception {
        Cliente cliente = (Cliente) objeto;
        PreparedStatement ps = getConexao().prepareStatement("insert into categoria (nome) values (?)");
        ps.setInt(1, cliente.getID());
        ps.setString(2, cliente.getNome());
        ps.setInt(3, cliente.getCPF());
        ps.setInt(4, cliente.getCNPJ());
        ps.setInt(5, cliente.getTelefone());
        ps.setInt(6, cliente.getResidencial());
        ps.setString(7, cliente.getRua());
        ps.setInt(8, cliente.getNumero());
        ps.setString(9, cliente.getBairro());
        ps.setString(10, cliente.getCidade());

        ps.executeUpdate();
    }

    @Override
    public void excluir(Object objeto) throws Exception {
        Cliente cliente = (Cliente) objeto;
        PreparedStatement ps = getConexao().prepareStatement("delete from categoria where id = ?");
        ps.setInt(1, cliente.getID());
        ps.executeUpdate();
    }

    @Override
    public List listar() throws Exception {
        PreparedStatement ps = getConexao().prepareStatement("select * from categoria order by nome");
        ResultSet rs = ps.executeQuery();
        List<Cliente> clientes = new ArrayList();
        while (rs.next()) {
            Cliente c = new Cliente(rs.getInt("ID"), rs.getString("Nome"), rs.getInt("CPF"), rs.getInt("CNPJ"), rs.getInt("Celular"), rs.getInt("Residencial"), rs.getString("Rua"), rs.getInt("Numero"), rs.getString("Bairro"), rs.getString("Cidade"));
            clientes.add(c);
        }
        return clientes;

    }

    @Override
    public void alterar(Object objeto) throws Exception {
        Cliente cliente = (Cliente) objeto;
        PreparedStatement ps = getConexao().prepareStatement("update categoria set nome = ? where id = ?");
        ps.setInt(1, cliente.getID());
        ps.setString(2, cliente.getNome());
        ps.setInt(3, cliente.getCPF());
        ps.setInt(4, cliente.getCNPJ());
        ps.setInt(5, cliente.getTelefone());
        ps.setInt(6, cliente.getResidencial());
        ps.setString(7, cliente.getRua());
        ps.setInt(8, cliente.getNumero());
        ps.setString(9, cliente.getBairro());
        ps.setString(10, cliente.getCidade());

        ps.executeUpdate();
    }

}
