/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 *
 * @author acg
 */
public abstract class Persistencia {

    private final String url = "jdbc:postgresql://localhost:5432/";
    private final String usuario = "postgres";
    private final String senha = "femass";
    private final String dataBase = "Oficina";

    protected Connection getConexao() throws SQLException, ClassNotFoundException {
        Connection conn = null;
        Class.forName("org.postgresql.Driver");
        conn = DriverManager.getConnection(url + dataBase, usuario, senha);
        return conn;
    }
    
    
}
