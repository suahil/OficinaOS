/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import model.Servico;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;
/**
 *
 * @author suahi
 */
public class ServicoDao extends Persistencia implements Dao {

    @Override
    public void gravar(Object objeto) throws Exception {
        Servico servico = (Servico) objeto;
        PreparedStatement ps = getConexao().prepareStatement("insert into categoria (nome) values (?)");
        ps.setInt(1, servico.getID());
//        ps.setString(2, servico.getTipoServico());
        ps.setDouble(3, servico.getValor());

        ps.executeUpdate();
    }

    @Override
    public void excluir(Object objeto) throws Exception {
        Servico servico = (Servico) objeto;
        PreparedStatement ps = getConexao().prepareStatement("delete from categoria where id = ?");
        ps.setInt(1, servico.getID());
//        ps.setString(2, servico.getTipoServico());
        ps.setDouble(3, servico.getValor());
        //verificar se esta certo, caso estiver modificar nos outros
        ps.executeUpdate();
    }

    @Override
    public List listar() throws Exception {
//        PreparedStatement ps = getConexao().prepareStatement("select * from categoria order by nome");
//        ResultSet rs = ps.executeQuery();
//        List<Servico> servicos = new ArrayList();
//        while (rs.next()) {
//            Servico s = new Servico(rs.getInt("ID"), rs.getString("Tipo"), rs.getDouble("Valor"));
//            servicos.add(s);
//        }
//        return servicos;
        return null;

    }

    @Override
    public void alterar(Object objeto) throws Exception {
        Servico servico = (Servico) objeto;
        PreparedStatement ps = getConexao().prepareStatement("update categoria set nome = ? where id = ?");
        ps.setInt(1, servico.getID());
//        ps.setString(2, servico.getTipoServico());
        ps.setDouble(3, servico.getValor());

        ps.executeUpdate();
    }
}
