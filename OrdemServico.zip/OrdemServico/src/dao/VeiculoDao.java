/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import model.Veiculo;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import model.Proprietario;

/**
 *
 * @author suahi
 */
public class VeiculoDao extends Persistencia implements Dao {

    public void gravar(Object objeto) throws Exception {
        Veiculo veiculo = (Veiculo) objeto;
        PreparedStatement ps = getConexao().prepareStatement("insert into categoria (nome) values (?)");
        ps.setInt(1, veiculo.getRenavan());
        ps.setString(2, veiculo.getMontadora());
        ps.setString(3, veiculo.getPlaca());
        ps.setString(4, veiculo.getModelo());
        ps.setInt(1, veiculo.getAno());

        ps.executeUpdate();
    }

    @Override
    public void excluir(Object objeto) throws Exception {
        Veiculo veiculo = (Veiculo) objeto;
        PreparedStatement ps = getConexao().prepareStatement("delete from categoria where id = ?");
        ps.setInt(1, veiculo.getRenavan());
        ps.setString(2, veiculo.getMontadora());
        ps.setString(3, veiculo.getPlaca());
        ps.setString(4, veiculo.getModelo());
        ps.setInt(1, veiculo.getAno());
        //verificar se esta certo, caso estiver modificar nos outros
        ps.executeUpdate();
    }

    @Override
    public List listar() throws Exception {
//        PreparedStatement ps = getConexao().prepareStatement("select * from categoria order by renavan");
//        ResultSet rs = ps.executeQuery();
//        List<Veiculo> veiculos = new ArrayList<>();
//        while (rs.next()) {
//            Veiculo v = new Veiculo(rs.getInt("Renavan"), rs.getString("Montadora"), rs.getString("Placa"), rs.getString("Modelo"), rs.getInt("Ano"));
//            veiculos.add(v);
//        }
//        return veiculos;
        return null;
    }

    @Override
    public void alterar(Object objeto) throws Exception {
        Veiculo veiculo = (Veiculo) objeto;
        PreparedStatement ps = getConexao().prepareStatement("update categoria set nome = ? where id = ?");
        ps.setInt(1, veiculo.getRenavan());
        ps.setString(2, veiculo.getMontadora());
        ps.setString(3, veiculo.getPlaca());
        ps.setString(4, veiculo.getModelo());
        ps.setInt(1, veiculo.getAno());

        ps.executeUpdate();
    }
}
