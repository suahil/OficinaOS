/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import model.Peca;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;
/**
 *
 * @author suahi
 */
public class PecaDao extends Persistencia implements Dao{
   @Override
    public void gravar(Object objeto) throws Exception {
        Peca peca = (Peca) objeto;
        PreparedStatement ps = getConexao().prepareStatement("insert into categoria (nome) values (?)");
        ps.setInt(1, peca.getCodigo());
        ps.setString(2, peca.getModelo());
        ps.setString(3, peca.getNome());
        
        ps.executeUpdate();
    }

    @Override
    public void excluir(Object objeto) throws Exception {
        Peca peca = (Peca) objeto;
        PreparedStatement ps = getConexao().prepareStatement("delete from categoria where id = ?");
        ps.setInt(1, peca.getCodigo());
        ps.setString(2, peca.getModelo());
        ps.setString(3, peca.getNome());
        //verificar se esta certo, caso estiver modificar nos outros
        ps.executeUpdate();
    }

    @Override
    public List listar() throws Exception {
        PreparedStatement ps = getConexao().prepareStatement("select * from categoria order by nome");
        ResultSet rs = ps.executeQuery();
        List<Peca> pecas = new ArrayList();
        while (rs.next()) {
            Peca p = new Peca(rs.getInt("Codigo"), rs.getString("Modelo"),rs.getString("Nome"));
            pecas.add(p);
        }
        return pecas;
        
    }

    @Override
    public void alterar(Object objeto) throws Exception {
        Peca peca = (Peca) objeto;
        PreparedStatement ps = getConexao().prepareStatement("update categoria set nome = ? where id = ?");
        ps.setInt(1, peca.getCodigo());
        ps.setString(2, peca.getModelo());
        ps.setString(3, peca.getNome());
        
        ps.executeUpdate();        
    }    
}
